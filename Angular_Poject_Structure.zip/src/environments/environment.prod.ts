export const environment = {
  production: true,
  server_url: 'https://example.com/backend/public',
};
